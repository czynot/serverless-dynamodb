# serverless-dynamodb

### Invoking the HTTP POST endpoint
`curl -X POST https://8o4k6dbfl7.execute-api.us-east-1.amazonaws.com/dev/todos --data '{ "text": "Item 1" }'`